using MiAPP.Models;
using MiAPP.Repositories;

namespace MiAPP.Services;

public interface IProductoService
{
    IEnumerable<Producto> ObtenerTodos();
    IEnumerable<Producto> BuscarProductos(string criterio);
    void Agregar(Producto producto);
    void Actualizar(Producto producto);
    void Eliminar(int id);
    Producto? ObtenerPorId(int id);
}

public class ProductoService : IProductoService
{
    private readonly IProductoRepository _productoRepository;

    public ProductoService(IProductoRepository productoRepository)
    {
        _productoRepository = productoRepository;
    }

    public IEnumerable<Producto> ObtenerTodos()
    {
        return _productoRepository.ObtenerTodos();
    }

     public IEnumerable<Producto> BuscarProductos(string criterio)
    {
        return _productoRepository.BuscarProductos(criterio);
    }

    public void Agregar(Producto producto)
    {
        _productoRepository.Agregar(producto);
    }

    public void Actualizar(Producto producto)
    {
        _productoRepository.Actualizar(producto);
    }

    public void Eliminar(int id)
    {
        _productoRepository.Eliminar(id);
    }

    public Producto? ObtenerPorId(int id)
    {
        return _productoRepository.ObtenerPorId(id);
    }
}
