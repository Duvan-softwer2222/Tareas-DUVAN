using MiAPP.Data;
using MiAPP.Models;
using MiAPP.Services;

namespace  MiAPP.Repositories; 

public interface IProductoRepository
{
    IEnumerable<Producto> ObtenerTodos();
    IEnumerable<Producto> BuscarProductos(string criterio);
    void Agregar(Producto producto);
    void Actualizar(Producto producto);
    void Eliminar(int id);
    Producto? ObtenerPorId(int id);
}

public class ProductoRepository : IProductoRepository
{
    
    private readonly AppDbContext _context;


    public ProductoRepository(AppDbContext context)
    {
        _context = context;
    }

    public IEnumerable<Producto> ObtenerTodos()
    {
        return _context.Productos.ToList();
    }

    public IEnumerable<Producto> BuscarProductos(string criterio)
    {
        return _context.Productos
            .Where(p => p.Nombre.Contains(criterio) || p.Descripcion.Contains(criterio) || p.Categoria.Contains(criterio))
            .ToList();
    }
    
    public void Agregar(Producto producto)
    {
        _context.Productos.Add(producto);
        _context.SaveChanges();
    }

    public void Actualizar(Producto producto)
{
    var productoExistente = _context.Productos.Find(producto.Id);
    if (productoExistente != null)
    {
        productoExistente.Nombre = producto.Nombre;
        productoExistente.Descripcion = producto.Descripcion;
        productoExistente.Precio = producto.Precio;
        productoExistente.Categoria = producto.Categoria;
        
        _context.SaveChanges();
    }
}

public void Eliminar(int id)
{
    var producto = _context.Productos.Find(id);
    if (producto != null)
    {
        _context.Productos.Remove(producto);
        _context.SaveChanges();
    }
}

public Producto? ObtenerPorId(int id)
{
    return _context.Productos.Find(id);
}
}