using MiAPP.Data;
using MiAPP.Models;
using MiAPP.Services;
using Microsoft.AspNetCore.Mvc;

namespace MiAPP.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IProductoService _productoService;

    public HomeController(ILogger<HomeController> logger, IProductoService productoService)
    {
        _logger = logger;
        _productoService = productoService;
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult Products()
    {
        var productos = _productoService.ObtenerTodos();
        return View("Products", productos);
    }

    public IActionResult AddProduct()
    {
        return View(new Producto { Nombre = string.Empty, Descripcion = string.Empty, Categoria = string.Empty });
    }



    [HttpPost]
    public IActionResult AddProduct(Producto producto)
    {
        if (ModelState.IsValid)
        {
            _productoService.Agregar(producto);
            return RedirectToAction("Products");
        }
        return View(producto);
    }

    public IActionResult Buscar(string criterio)
    {
        var productos = _productoService.BuscarProductos(criterio);

        if (!productos.Any())
        {
            ViewBag.Mensaje = $"El producto '{criterio}' no existe.";
            productos = _productoService.ObtenerTodos();
        }

        return View("Products", productos);
    }

    public IActionResult Edit(int id)
    {
        var producto = _productoService.ObtenerPorId(id);
        if (producto == null) return NotFound();
        return View(producto);
    }

    [HttpPost]
    public IActionResult Edit(Producto producto)
    {
        if (ModelState.IsValid)
        {
            _productoService.Actualizar(producto);
            return RedirectToAction("Products");
        }
        return View(producto);
    }

    public IActionResult Delete(int id)
    {
        var producto = _productoService.ObtenerPorId(id);
        if (producto == null) return NotFound();
        return View(producto);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        _productoService.Eliminar(id);
        return RedirectToAction("Products");
    }
}
